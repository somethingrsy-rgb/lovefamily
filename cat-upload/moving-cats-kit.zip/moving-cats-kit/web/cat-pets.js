/* 루비·크리스탈 움직이는 고양이 (웹페이지용, 라이브러리 필요 없음)
 * 사용법: <script src="cat-dims.js"></script><script src="play.js"></script><script src="cat-pets.js"></script>
 *         <script>CatPets.start({ frames: 'frames/' })</script>
 * 옵션: frames(그림 폴더, 끝에 /), size(1=보통), floor(바닥 y좌표 px, 기본 화면 맨 아래), playEvery([최소,최대] ms, 기본 [55000,70000]),
 *       scenes(true/false: 만나면 장난), ruby(true/false), crystal(true/false), zIndex
 * 반환: { stop(), setSize(n), play() 두 마리 불러서 장난, hide(), show() }
 */
(function () {
  var SCALE = 0.8
  var rnd = function (a) { return a[Math.floor(Math.random() * a.length)] }
  function start(opts) {
    opts = opts || {}
    var D = window.CAT_DIMS, base = opts.frames || 'frames/', size = opts.size || 1
    var every = opts.playEvery || [55000, 70000]
    var cats = [], layer = document.createElement('div'), alive = true, last = performance.now()
    layer.style.cssText = 'position:fixed;left:0;top:0;width:100%;height:100%;pointer-events:none;overflow:hidden;z-index:' + (opts.zIndex || 2147483000)
    document.body.appendChild(layer)
    var floorY = function () { return typeof opts.floor === 'number' ? opts.floor : window.innerHeight - 2 }
    var W = function () { return window.innerWidth }
    var unit = function () { return D.dim.walkR0.w * SCALE * size }
    var n = function (pre, g) { return D.count[pre + g] }

    function makeCat(pre, name, x0) {
      var el = document.createElement('div'), img = document.createElement('img')
      el.style.cssText = 'position:absolute;left:0;top:0;will-change:transform;pointer-events:auto;cursor:pointer'
      img.style.cssText = 'display:block;-webkit-user-drag:none;user-select:none'; img.draggable = false
      el.appendChild(img); layer.appendChild(el)
      var st = { x: x0, dir: 1, mode: 'stand', until: performance.now() + 1500 + Math.random() * 3000, ov: null, frozen: false }
      var STAND = pre === 'wh_' ? 'wh_stand0' : 'up0'
      function frame(now) {
        switch (st.mode) {
          case 'walk': case 'goto': return pre + (st.dir > 0 ? 'walkR' : 'walkL') + (Math.floor(now / 150) % n(pre, st.dir > 0 ? 'walkR' : 'walkL'))
          case 'aegyo': return pre + 'aegyo0'
          case 'sit': return pre + 'sit0'
          case 'sleep': return pre + 'sleep0'
          case 'groom': return pre + 'groom0'
          default: return STAND
        }
      }
      function draw(key, x, flip) {
        var d = D.dim[key]; if (!d) return
        var w = d.w * SCALE * size, h = d.h * SCALE * size
        if (img.dataset.k !== key) { img.src = base + key + '.webp'; img.dataset.k = key }
        img.style.width = w + 'px'; img.style.height = h + 'px'; img.style.transform = flip ? 'scaleX(-1)' : ''
        el.style.transform = 'translate(' + Math.round(x - w / 2) + 'px,' + Math.round(floorY() - h) + 'px)'
      }
      function update(now, dt) {
        if (st.frozen) { if (st.ov) draw(st.ov.key, st.ov.x, st.ov.flip); return }
        var key = frame(now), w = D.dim[key].w * SCALE * size
        if (st.mode === 'goto') {
          var dd = st.gx - st.x, step = 0.5 * w * dt; st.dir = dd >= 0 ? 1 : -1
          if (Math.abs(dd) <= step) { st.x = st.gx; st.mode = 'stand'; st.until = now + 60000 } else st.x += st.dir * step
        } else if (now > st.until) {
          var r = Math.random()
          if (r < 0.55) { st.mode = 'walk'; st.dir = Math.random() < 0.5 ? -1 : 1; st.until = now + 5000 + Math.random() * 9000 }
          else { st.mode = rnd(['sit', 'sit', 'sleep', 'groom', 'stand']); st.until = now + 8000 + Math.random() * 6000 }
        }
        if (st.mode === 'walk') {
          st.x += st.dir * 0.3 * w * dt
          var m = w * 0.5 + 6
          if (st.x < m) { st.x = m; st.dir = 1 } else if (st.x > W() - m) { st.x = W() - m; st.dir = -1 }
        }
        draw(frame(now), st.x, !['walk', 'goto'].includes(st.mode) && st.dir < 0)
      }
      el.addEventListener('click', function () {   // 눌러 주면 애교
        if (st.frozen) return
        var now = performance.now(); st.mode = 'aegyo'; st.until = now + 4500
        var b = el.getBoundingClientRect()
        for (var i = 0; i < 3; i++) {
          var h = document.createElement('div'); h.textContent = '♥'
          h.style.cssText = 'position:absolute;font-size:22px;color:#ff6fa5;pointer-events:none;transition:all 1.4s ease-out;opacity:1;left:' + (b.left + b.width / 2 + (i - 1) * 26 - 10) + 'px;top:' + (b.top - 10) + 'px'
          layer.appendChild(h)
          requestAnimationFrame(function (hh) { return function () { hh.style.transform = 'translateY(-70px)'; hh.style.opacity = '0' } }(h))
          setTimeout(function (hh) { return function () { hh.remove() } }(h), 1500)
        }
      })
      return { st: st, el: el, name: name, pre: pre, update: update, remove: function () { el.remove() } }
    }

    var ruby = opts.ruby === false ? null : makeCat('', '루비', W() * (0.2 + Math.random() * 0.25))
    var crystal = opts.crystal === false ? null : makeCat('wh_', '크리스탈', W() * (0.6 + Math.random() * 0.25))
    cats = [ruby, crystal].filter(Boolean)

    // ── 두 마리가 걷다가 마주치면 장난 (play.js 의 buildScene) ──
    var scene = null, lastScene = performance.now() - 20000, cooldown = every[0] + Math.random() * (every[1] - every[0]), pending = null
    var FREE = ['stand', 'sit', 'sleep', 'groom', 'walk']
    function begin(a, b, now, plan) {
      scene = { plan: plan, t0: now, leftIs: a.st.x <= b.st.x ? a : b }
      cats.forEach(function (c) { c.st.frozen = true })
    }
    function endScene() {
      if (!scene) return
      var sc = scene, fin = sc.plan.at(Math.min(performance.now() - sc.t0, sc.plan.dur - 1)); scene = null
      var left = sc.leftIs, right = cats[0] === left ? cats[1] : cats[0]
      ;[[left, fin.L.x, 1], [right, fin.R.x, -1]].forEach(function (a) {
        var c = a[0]; c.st.frozen = false; c.st.ov = null; c.st.x = a[1]; c.st.dir = a[2]; c.st.mode = 'sit'; c.st.until = performance.now() + 1000
      })
      lastScene = performance.now(); cooldown = every[0] + Math.random() * (every[1] - every[0])
    }
    function director(now) {
      if (cats.length < 2 || opts.scenes === false) return
      var a = ruby.st, b = crystal.st
      if (scene) {
        var el = now - scene.t0
        if (el >= scene.plan.dur) return endScene()
        var s = scene.plan.at(el), rs = scene.leftIs === ruby ? s.L : s.R, cs = scene.leftIs === ruby ? s.R : s.L
        ruby.st.ov = { x: rs.x, key: playKey('', rs), flip: rs.flip }; crystal.st.ov = { x: cs.x, key: playKey('wh_', cs), flip: cs.flip }
        return
      }
      var u = unit(), lo = u * 0.6 + 6, hi = W() - u * 0.6 - 6
      if (pending) {
        var arrived = a.mode !== 'goto' && b.mode !== 'goto'
        if (now - pending.t > 800 && (arrived || now - pending.t > 25000)) {
          var cx = pending.x; pending = null
          if (!arrived) { a.x = cx - u * 0.45; b.x = cx + u * 0.45 }
          begin(ruby, crystal, now, buildScene(pickActions(), Math.min(a.x, b.x), Math.max(a.x, b.x), u, lo, hi, 0.3 * u, 0.75))
        }
        return
      }
      if (now - lastScene < cooldown || !FREE.includes(a.mode) || !FREE.includes(b.mode)) return
      if (Math.abs(a.x - b.x) > 1.6 * u) return
      var away = function (c, o) { return c.mode === 'walk' && Math.sign(c.dir) === Math.sign(c.x - o.x) }
      if (away(a, b) || away(b, a)) return
      begin(ruby, crystal, now, buildScene(pickActions(), Math.min(a.x, b.x), Math.max(a.x, b.x), u, lo, hi, 0.3 * u, 0.75))
    }

    function loop(now) {
      if (!alive) return
      var dt = Math.min(0.1, (now - last) / 1000); last = now
      cats.forEach(function (c) { c.update(now, dt) })
      director(now)
      requestAnimationFrame(loop)
    }
    // 이미지를 미리 불러와 깜빡임을 줄여요
    Object.keys(D.dim).forEach(function (k) { var i = new Image(); i.src = base + k + '.webp' })
    requestAnimationFrame(loop)
    return {
      stop: function () { alive = false; layer.remove() },
      setSize: function (v) { size = v },
      hide: function () { layer.style.display = 'none' }, show: function () { layer.style.display = '' },
      play: function (x) {   // 두 마리를 화면 가운데(또는 x)로 불러서 장난쳐요
        if (cats.length < 2 || scene) return
        var cx = typeof x === 'number' ? x : W() / 2, h = unit() * 0.45, rl = ruby.st.x <= crystal.st.x
        ;[[ruby, cx + (rl ? -h : h)], [crystal, cx + (rl ? h : -h)]].forEach(function (p) { p[0].st.mode = 'goto'; p[0].st.gx = p[1] })
        pending = { t: performance.now(), x: cx }
      },
    }
  }
  window.CatPets = { start: start }
})()
