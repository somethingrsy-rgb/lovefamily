# 🐱 루비 · 크리스탈 움직이는 고양이 키트

다른 앱·웹페이지에 고양이를 붙일 수 있게 정리한 묶음이에요. 용도에 맞는 폴더 하나만 쓰면 돼요.

| 폴더 | 용도 | 난이도 |
|---|---|---|
| `web/` | **웹페이지·웹앱**에 바로 붙이기 (라이브러리 필요 없음) | 가장 쉬움 |
| `electron-desktop-pet/` | **윈도우 바탕화면 펫**(Ruby-Cat.exe) 소스 | 보통 |
| `react-reference/` | React/SVG 앱에 직접 넣을 때 참고하는 소스 (마이미니월드가 쓰는 방식) | 어려움 |
| `sprite-sources/` | 고양이 **원본 그림**과 그림을 자르는 스크립트 (다른 고양이로 바꿀 때) | 선택 |

---

## 1. 웹페이지에 붙이기 (`web/`)

1. `web/` 폴더의 `cat-dims.js`, `play.js`, `cat-pets.js`, `frames/` 폴더를 내 사이트 폴더에 복사해요.
2. 페이지 맨 아래에 이렇게 넣어요.

```html
<script src="cat-dims.js"></script>
<script src="play.js"></script>
<script src="cat-pets.js"></script>
<script>
  var pets = CatPets.start({ frames: 'frames/' })   // frames 폴더 위치
</script>
```

먼저 `web/demo.html`을 열어서 동작을 확인해 보세요 (파일을 더블클릭하면 돼요).

### 옵션
| 옵션 | 설명 | 기본 |
|---|---|---|
| `frames` | 그림 폴더 경로 (끝에 `/`) | `'frames/'` |
| `size` | 크기 (0.7 작게 / 1 보통 / 1.4 크게) | `1` |
| `floor` | 고양이가 서 있는 바닥 높이(px) | 화면 맨 아래 |
| `ruby`, `crystal` | `false`로 하면 그 고양이는 안 나와요 | 둘 다 `true` |
| `scenes` | `false`면 만나도 장난 안 쳐요 | `true` |
| `playEvery` | 장난 간격 `[최소, 최대]` ms | `[55000, 70000]` |
| `zIndex` | 다른 요소 위/아래 | 아주 높음 |

### 쓸 수 있는 명령
```js
pets.play()        // 두 마리를 화면 가운데로 불러서 장난치게
pets.play(300)     // x=300px 자리로 불러서
pets.setSize(1.4)  // 크기 바꾸기
pets.hide(); pets.show()
pets.stop()        // 고양이 없애기
```

### 동작
- 화면 아래쪽을 걷고, 앉고, 자고, 털을 핥아요.
- 고양이를 누르면 하트와 함께 애교를 부려요.
- 두 마리가 걷다가 마주치면 **코 비비기·앞발 톡톡·장난 걸기·쫓고 쫓기·뒹굴기** 중 두 가지를 골라 장난쳐요 (조합 20가지, 약 1분에 한 번).
- 고양이 그림 부분만 눌려요. 나머지 화면은 그대로 클릭돼요.

### 알아 둘 점
- 파일을 `file://`로 열어도 되지만, 사이트에 올릴 때는 `frames/` 폴더도 함께 올려야 해요.
- 그림은 약 3MB(270장)예요. 필요 없는 동작(`up`, `down`, `pounce` 등 점프 그림)은 지워도 되지만, 지우면 `cat-dims.js`의 해당 항목도 맞춰야 해요.
- 페이지가 스크롤돼도 고양이는 화면(창) 맨 아래에 고정돼서 따라다녀요.

---

## 2. 윈도우 바탕화면 펫 (`electron-desktop-pet/`)

Electron 프로젝트예요. 이 폴더가 곧 Ruby-Cat.exe의 소스예요.

- 실행해 보기: `npm install` 후 `npx electron .`
- exe 만들기: `npm run dist` (윈도우에서) 또는 깃허브에 올리고 `build-workflow-desktop-cat.yml`을 `.github/workflows/desktop-cat.yml`로 복사하면 Actions에서 exe를 만들어 줘요.
- 기능 설명은 `electron-desktop-pet/README.md`에 있어요 (정각 LED, 18시 e-사람 체크, 집중 모드, 오른쪽 클릭 타이머 등).
- 고양이 움직임 규칙은 `renderer.js`, 장난 장면은 `play.js`에 있어요.

---

## 3. React / SVG 앱에 넣기 (`react-reference/`)

- `Cat.tsx`: 고양이 한 마리의 걷기·쉬기·애교·점프 규칙 (마이미니월드용이라 집 구조(`schedule`, `assets`)에 묶여 있어서 그대로 복사하면 안 돼요. 규칙을 참고해서 맞춰 쓰세요).
- `playScene.ts`: 두 마리 장난 장면을 만드는 순수 함수. **어디에나 그대로 쓸 수 있어요.** (`web/play.js`가 이 파일을 자바스크립트로 바꾼 거예요.)
- `cats.gen.ts`: 그림 크기 표.

React에서 가장 쉬운 방법은 `web/` 키트를 `public/`에 넣고 `useEffect(() => { const p = CatPets.start({ frames: '/frames/' }); return () => p.stop() }, [])`로 붙이는 거예요.

---

## 4. 그림 바꾸기 (`sprite-sources/`)

- `*.png`: 12칸(4×3) 동작 시트 원본이에요. 같은 규칙으로 다른 고양이를 그리면 교체할 수 있어요.
- `process_cats.py`: 시트를 잘라서 `cats/*.webp`와 크기 표를 만들어요 (python3, numpy, scipy, Pillow 필요).
- 이름 규칙: 루비는 `walkR0`처럼, 크리스탈은 앞에 `wh_`가 붙어요 (`wh_walkR0`).

## 동작 그림 목록 (고양이마다 12프레임)
`walkR` 오른쪽 걷기 · `walkL` 왼쪽 걷기 · `sneak` 살금살금 · `sniff` 코 비비기 · `bow` 장난 걸기 · `tap` 앞발 톡톡 · `roll` 뒹굴기 · `dash` 달리기 · `up`/`down` 위·아래로 뛰기 · `pounce` 잡으려는 동작 · 1프레임: `sit` `sleep` `groom` `aegyo`

## 주의
고양이 그림을 다른 곳에 배포하거나 판매할 때는 그림을 만든 도구의 이용 약관(사용 권리)을 먼저 확인해 주세요.
